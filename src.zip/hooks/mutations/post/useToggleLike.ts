import { useMutation } from '@tanstack/react-query';
import { togglePostLike } from '@/apis/post';
import { UseMutationCallback } from '@/types/types';

export function useTogglePostLike(callback?: UseMutationCallback) {
  return useMutation({
    mutationFn: togglePostLike,
    onSuccess: () => {
      if (callback?.onSuccess) callback.onSuccess();
    },
    onError: error => {
      if (callback?.onError) callback.onError(error);
    },
  });
}
