'use client';
import { usePostsData } from '@/hooks/queries/usePostsData';
import FallBack from '../FallBack';
import Loader from '../Loader';
import PostItem from './PostItem';

// intersectionObjser
import { useInView } from 'react-intersection-observer';

export default function PostFeed() {
  const { data, error, isPending } = usePostsData();

  // intersectionObserver 레퍼런스
  const { ref, inView } = useInView();

  if (error) return <FallBack />;
  if (isPending) return <Loader />;
  return (
    <div className='flex flex-col gap-10'>
      {data?.map(post => (
        <PostItem key={post.id} {...post} />
      ))}
      {/* 웹브라우저 하단 감지용 DOM 요소를 추가 */}
      <div ref={ref}></div>
    </div>
  );
}
