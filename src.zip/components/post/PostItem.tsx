'use client';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from '@/components/ui/carousel';
import { usePostByIdData } from '@/hooks/queries/usePostByIdData';
import { formatTimeAgo } from '@/lib/time';
import { useSession } from '@/stores/session';
import { MessageCircle } from 'lucide-react';
import Image from 'next/image';
import FallBack from '../FallBack';
import Loader from '../Loader';
import DeletePostButton from './DeletePostButton';
import EditPostItemButton from './EditPostItemButton';
import LikeButton from './LikeButton';
import defaultAvatar from '/public/assets/icons/default-avatar.jpg';

export default function PostItem({ postId }: { postId: number }) {
  // 내가 만든 post 인지 확인
  const session = useSession();
  const userId = session?.user.id;
  // 실제 쿼리로 id 를 전달해서 post를 가져오자.
  const {
    data: post,
    isPending,
    error,
  } = usePostByIdData({ postId, type: 'FEED' });

  if (isPending) return <Loader />;
  if (error) return <FallBack />;

  const isMine = userId === post.author.id;

  return (
    <div className='flex flex-col gap-4 border-b pb-8'>
      {/* 1. 유저 정보, 수정/삭제 버튼 */}
      <div className='flex justify-between'>
        {/* 1-1. 유저 정보 */}
        <div className='flex items-start gap-4'>
          <Image
            src={post.author.avatar_url || defaultAvatar}
            alt={`${post.author.nickname}의 프로필 이미지`}
            className='h-10 w-10 rounded-full object-cover'
            width={40}
            height={40}
          />
          <div>
            <div className='font-bold hover:underline'>
              {post.author.nickname}
            </div>
            <div className='text-muted-foreground text-sm'>
              {formatTimeAgo(post.created_at)}
              {/* {new Date(post.created_at).toLocaleString()} */}
            </div>
          </div>
        </div>

        {/* 1-2. 수정/삭제 버튼 */}
        <div className='text-muted-foreground flex text-sm'>
          {isMine && (
            <>
              <EditPostItemButton {...post} />
              <DeletePostButton id={post.id} />
            </>
          )}
        </div>
      </div>

      {/* 2. 컨텐츠, 이미지 캐러셀 */}
      <div className='flex cursor-pointer flex-col gap-5'>
        {/* 2-1. 컨텐츠 */}
        <div className='line-clamp-2 break-words whitespace-pre-wrap'>
          {post.content}
        </div>

        {/* 2-2. 이미지 캐러셀 */}
        <Carousel>
          <CarouselContent>
            {post.image_urls?.map((url, index) => (
              <CarouselItem className={`basis-3/5`} key={index}>
                <div className='overflow-hidden rounded-xl'>
                  <img
                    src={url}
                    className='h-full max-h-[350px] w-full object-cover'
                  />
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
        </Carousel>
      </div>

      {/* 3. 좋아요, 댓글 버튼 */}
      <div className='flex gap-2'>
        {/* 3-1. 좋아요 버튼 */}
        <LikeButton
          id={post.id}
          likeCount={post.like_count}
          isLiked={post.isLiked}
        />

        {/* 3-2. 댓글 버튼 */}
        <div className='hover:bg-muted flex cursor-pointer items-center gap-2 rounded-xl border-1 p-2 px-4 text-sm'>
          <MessageCircle className='h-4 w-4' />
          <span>댓글 달기</span>
        </div>
      </div>
    </div>
  );
}
