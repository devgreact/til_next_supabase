'use client';
import { Toaster } from '../ui/sonner';
export default function ToastProvider() {
  return <Toaster />;
}
