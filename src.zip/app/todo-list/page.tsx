'use client';
import TodoEditor from '@/components/todo/TodoEditor';
import TodoItem from '@/components/todo/TodoItem';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';

type Todo = {
  id: number;
  userId: number;
  title: string;
  completed: boolean;
};

// API 함수로 할일 목록 전체 불러들이기 기능
async function fetchTodos() {
  const response = await fetch('https://jsonplaceholder3.typicode.com/todos');
  if (!response.ok) throw new Error('목록을 가져오는데 실패함');
  const todos: Todo[] = await response.json();
  return todos;
}

export default function TodoListPage() {
  const {
    data: todos,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['todos'],
    queryFn: fetchTodos,
    retry: 3,
  });

  if (isLoading) return <div>로딩중 ...</div>;
  if (error) return <div>에러입니다: {error.message}</div>;
  if (!todos) return <div>데이터가 없습니다.</div>;

  return (
    <div className='flex flex-col gap-5 p-5'>
      <h1 className='text-2xl font-bold'>Todo List</h1>
      <TodoEditor />
      <div className='flex flex-col gap-2'>
        {todos.map(item => (
          <TodoItem key={item.id} id={item.id} content={item.title} />
        ))}
      </div>
    </div>
  );
}
